zwhand_17dof功能包支持兆威17自由度灵巧手在ROS平台上的使用,该功能包在Ubuntu 20.04系统的ROS Noetic环境下进行测试.
1.配置ROS Noetic环境,安装方式如下:
	进行源设置：
		sudo sh -c 'echo "deb http://packages.ros.org/ros/ubuntu $(lsb_release -sc) main" > /etc/apt/sources.list.d/ros-latest.list'
	添加 ROS GPG key：
		sudo apt-key adv --keyserver 'hkp://keyserver.ubuntu.com:80' --recv-key C1CF6E31E6BADE8868B172B4F42ED6FBAB17C654
	更新软件源：
		sudo apt update
	安装完整桌面版：
		sudo apt install ros-noetic-desktop-full
	安装依赖管理工具：
		sudo apt install python3-rosdep -y
		sudo rosdep init
		rosdep update

2.安装本地环境
	(1)创建工作空间
	mkdir -p ~/{workspace_name}/src
	cd ~/{workspace_name}
	catkin_make
	将src文件夹中的内容复制到创建工作空间中的src文件夹中
	
	
	（2）对端口进行权限设置，可以选择临时方案或者是永久方案
        (1) 临时方案（每次使用都需要设置）。终端指令：sudo chmod a+rw /dev/ttyUSB*（* 是串口号）
        (2) 永久方案。
			sudo vim -p /etc/udev/rules.d/70-ttyUSB.rules
			在打开的文件中输入：
			KERNEL=="ttyUSB*", OWNER="root", GROUP="root", MODE="0666"
			保存关闭之后，重启电脑即可。（注意KERNEL=="ttyUSB*",这里的*不是串口号就是*）
	
	
3.控制灵巧手
	(1)连接串口：
        配置环境变量
		    source devel/setup.bash
		默认参数连接
			roslaunch zwhand_17dof zwhand_17dof.launch 
		设置参数连接
			roslaunch zwhand_17dof zwhand_17dof.launch baud:=115200 port:=/dev/ttyUSB0 hand_id:=1
	(2)在另一个终端启动服务：
	配置环境变量
		source devel/setup.bash
	接下来可以启动以下灵巧手服务：
	动作控制：
		全手校准
            ros2 service call /zwhand_17dof/calibration_all_hand interface/srv/CalibrationAllHand
		全步进电机校准
            rosservice call /zwhand_17dof/calibration_stepping_motors 
		单电机校准：
            rosservice call /zwhand_17dof/calibration_single_motor "motor_id: 0"
				输入电机id号，范围0-16,整数
		单电机绝对值控制：
            rosservice call /zwhand_17dof/control_single_motor "motor_id: 0
            angles: 0" 
				输入电机id号，范围0-16；	输入角度，范围0-1000,整数
		单电机增量控制：
            rosservice call /zwhand_17dof/control_single_motor_increment "motor_id: 0
            angles: 100" 
            angles: 0" 
				输入电机id号，范围0-16；	输入角度增量，范围0-1000,整数
		全手绝对值控制：
            rosservice call /zwhand_17dof/control_all_hand "angles: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]" 
				输入17个角度，范围0-1000,整数
		全手增量控制：
            rosservice call /zwhand_17dof/control_all_hand_increment "angles: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]"
				输入17个角度，范围0-1000,整数
		设置急停：
            rosservice call /zwhand_17dof/stop 
	设置参数：
		设置灵巧手ID
			rosservice call /zwhand_17dof/set_id "hand_id: 1"
		设置波特率
			rosservice call /zwhand_17dof/set_baudrate "baudrate: 115200"
			允许输入的波特率为{9600, 115200, 1152000}
		设置全手速度
			rosservice call /zwhand_17dof/set_speed_all_hand "velocity: [50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50]"
				输入电机速度，范围0-100,整数
		设置单电机速度
			rosservice call /zwhand_17dof/set_speed_single_motor "motor_id: 0
			velocity: 50" 
				输入电机id号，范围0-16；	输入电机速度，范围0-100,整数
		设置全手电流
			rosservice call /zwhand_17dof/set_current_all_hand "current: [50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50]"
				输入电机电流，范围0-100,整数
		设置单电机电流
			rosservice call /zwhand_17dof/set_current_single_motor "motor_id: 0
			current: 0"
				输入电机id号，范围0-16；	输入电机电流，范围0-100,整数
		设置掉电保存参数
			rosservice call /zwhand_17dof/save_configuration
		清楚错误：
			rosservice call /zwhand_17dof/clear_error
		恢复出厂设置：
			rosservice call /zwhand_17dof/restor_factory_settings
		


	读取参数：
		读取初始化成功信号：
			rosservice call /zwhand_17dof/get_initialization_success_signal
		读取BootLoader版本号：
			rosservice call /zwhand_17dof/get_bootloader_version
		读取硬件版本号：
			rosservice call /zwhand_17dof/get_hardware_version
		读取软件版本号：
			rosservice call /zwhand_17dof/get_software_version
		
		
	(3)在新的终端可以读取电机实时状态：
		全手实时角度：
			启动新终端
				source devel/setup.bash
				rosrun zwhand_17dof angle_subscriber.py
		全手堵转情况：
			启动新终端
				source devel/setup.bash
				rosrun zwhand_17dof motor_stall_subscriber.py 