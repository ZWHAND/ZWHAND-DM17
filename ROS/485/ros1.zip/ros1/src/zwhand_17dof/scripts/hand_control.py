import sys
import os
# 获取当前脚本（hand_control.py）的绝对路径
current_script_path = os.path.abspath(__file__)
# 提取scripts目录的路径（当前脚本的父目录）
scripts_dir = os.path.dirname(current_script_path)
# 将scripts目录插入到Python搜索路径的最前面（优先于ROS的devel目录）
sys.path.insert(0, scripts_dir)

# 2. 导入ROS相关模块
import rospy
from zwhand_17dof.srv import *
from zwhand_17dof.msg import RealtimeAngle, RealtimeMotorStall

# 3. 导入modbus_control_api中的hand_serial类
from modbus_control_api import hand_serial  # 关键：导入同一目录下的模块





class HandControlNode:  # 不继承任何类
    def __init__(self):
        # 初始化节点（ROS 1方式）
        rospy.init_node('hand_control_node')


        try:
            self.hand = hand_serial()
            rospy.loginfo(f"Serial port confirmed: {self.hand.port} @ {self.hand.baud}bps")  # 移到这里（确保打开成功后再打印）
        except Exception as e:
            rospy.logerr(f"Failed to open serial port: {str(e)}")
            rospy.signal_shutdown("Serial port initialization failed")  # 关闭节点
            return


        # 标志位：控制回调函数是否执行实际操作
        self.angle_callback_enabled = False
        self.stall_callback_enabled = False

        # movement service
        self.calibration_all_hand_service = rospy.Service(
            'zwhand_17dof/calibration_all_hand',
            CalibrationAllHand,
            self.hand.calibrationAllHandCallback
        )
        self.calibration_stepping_motors = rospy.Service(
            'zwhand_17dof/calibration_stepping_motors',
            CalibrationSteppingMotors,
            self.hand.calibrationSteppingMotorsCallback
        )
        self.calibration_single_motor = rospy.Service(
            'zwhand_17dof/calibration_single_motor',
            CalibrationSingleMotor,
            self.hand.calibrationSingleMotorCallback
        )


        self.control_all_hand_service = rospy.Service(
            'zwhand_17dof/control_all_hand',
            ControlAllHand,
            self.hand.controlAllHandCallback
        )
        self.control_single_motor_service = rospy.Service(
            'zwhand_17dof/control_single_motor',
            ControlSingleMotor,
            self.hand.controlSingleMotorCallback
        )


        self.control_all_hand_increment_service = rospy.Service(
            'zwhand_17dof/control_all_hand_increment',
            ControlAllhandIncrement,
            self.hand.ControlAllhandIncrementCallback
        )
        self.control_single_motor_increment_service = rospy.Service(
            'zwhand_17dof/control_single_motor_increment',
            ControlSingleMotorIncrement,
            self.hand.ControlSingleMotorIncrementCallback
        )





        self.set_ID_service = rospy.Service(
            'zwhand_17dof/set_id',
            SetID,
            self.hand.SetIdCallback
        )


        self.set_baudrate_service = rospy.Service(
            'zwhand_17dof/set_baudrate',
            SetBaudrate,
            self.hand.SetBaudrateCallback
        )

        self.set_speed_all_hand_service = rospy.Service(
            'zwhand_17dof/set_speed_all_hand',
            SetSpeedAllHand,
            self.hand.SetSpeedAllHandCallback
        )
        self.set_speed_single_motor_service = rospy.Service(
           'zwhand_17dof/set_speed_single_motor',
           SetSpeedSingleMotor,
            self.hand.SetSpeedSingleMotorCallback
        )


        self.set_current_single_motor_service = rospy.Service(
            'zwhand_17dof/set_current_single_motor',
            SetCurrentSingleMotor,
            self.hand.SetCurrentSingleMotorCallback
        )        
        self.set_current_all_hand_service = rospy.Service(
            'zwhand_17dof/set_current_all_hand',
            SetCurrentAllHand,
            self.hand.SetCurrentAllHandCallback
        )   


        self.clear_error_service = rospy.Service(
            'zwhand_17dof/clear_error',
            ClearError,
            self.hand.ClearErrorCallback
        )
        self.restor_factory_settings_service = rospy.Service(
            'zwhand_17dof/restor_factory_settings',
            RestoreFactorySettings,
            self.hand.RestoreFactorySettingsCallback
        )


        self.stop_emergency_service = rospy.Service(
            'zwhand_17dof/stop',
            StopEmergency,
            self.hand.StopEmergencyCallback
        )
        self.save_configuration_service = rospy.Service(
            'zwhand_17dof/save_configuration',
            SaveConfiguration,
            self.hand.SaveConfigurationCallback
        )

        self.get_initialization_success_signal_service = rospy.Service(
            'zwhand_17dof/get_initialization_success_signal',
            GetInitializationSignal,
            self.hand.GetInitializationSignalCallback
        )

        self.get_bootLoader_version_service = rospy.Service(
            'zwhand_17dof/get_bootloader_version',
            GetBootloaderVersion,
            self.hand.GetBootloaderVersionCallback
        )
        self.get_hardware_version_service = rospy.Service(
            'zwhand_17dof/get_hardware_version',
            GetHardwareVersion,
            self.hand.GetHardwareVersionCallback
        )
        self.get_software_version_service = rospy.Service(
            'zwhand_17dof/get_software_version',
            GetSoftwareVersion,
            self.hand.GetSoftwareVersionCallback
        )

        # -------------------- topic communication --------------------
        self.realtime_angle_publisher = rospy.Publisher(
            'zwhand_17dof/realtime_angle',  # 话题名称（与ROS 2保持一致）
            RealtimeAngle,                   # 消息类型
            queue_size=10                    # 队列长度
        )

        # 创建定时器，每0.1秒触发一次回调（ROS 1中使用rospy.Timer）
        # 周期用rospy.Duration(秒)表示，回调函数需接收一个TimerEvent参数
        self.realtime_angle_publisher_timer = rospy.Timer(
            rospy.Duration(0.1),  # 周期0.1秒（与ROS 2的0.1对应）
            self.RealtimeAngleCallback,  # 回调函数
            oneshot=False  # 循环执行
        )

        self.realtime_motor_stall_publisher = rospy.Publisher(
            'zwhand_17dof/realtime_motor_stall',  # 话题名称（与ROS 2保持一致）
            RealtimeMotorStall,                   # 消息类型（需在ROS 1中定义并生成）
            queue_size=10                        # 队列长度
        )

        # 创建定时器，每0.35秒触发一次回调
        self.realtime_motor_stall_publisher_timer = rospy.Timer(
            rospy.Duration(0.35),  # 周期0.35秒（用rospy.Duration封装）
            self.RealtimeMotorStallCallback,  # 回调函数
            oneshot=False  # 循环执行
        )

        rospy.Service('zwhand_17dof/enable_publishers', EnablePublishers, self.handle_enable_publishers)

        # --------------------------------------------------------------
        
        rospy.loginfo("Hand control node initialized successfully")

    def handle_enable_publishers(self, req):
        """处理启动/停止发布者的服务请求"""
        # 修正：用实际的定时器实例名 self.realtime_angle_publisher_timer
        if req.enable_angle:
            # ROS 1 定时器无 start()，需用“回调开关”（后续优化点会讲）
            self.angle_callback_enabled = True  
            rospy.loginfo("Realtime angle publisher enabled")
        else:
            self.angle_callback_enabled = False  
            rospy.loginfo("Realtime angle publisher disabled")
            
        # 修正：用实际的定时器实例名 self.realtime_motor_stall_publisher_timer
        if req.enable_stall:
            self.stall_callback_enabled = True  
            rospy.loginfo("Realtime motor stall publisher enabled")
        else:
            self.stall_callback_enabled = False  
            rospy.loginfo("Realtime motor stall publisher disabled")
            
        return EnablePublishersResponse(success=True)

    def RealtimeMotorStallCallback(self, event):
        """电机堵转信息回调函数"""
        # 检查是否启用了回调
        if not self.stall_callback_enabled:
            return
            
        try:
            realtime_motor_stall = self.hand.read_realtime_motor_stall()

            if realtime_motor_stall and len(realtime_motor_stall) == 17:
                msg = RealtimeMotorStall()
                msg.motor_stall = realtime_motor_stall
                self.realtime_motor_stall_publisher.publish(msg)
            else:
                rospy.logwarn("Failed to read valid realtime motor stall")
        except Exception as e:
            rospy.logerr(f"Error in realtime motor stall query: {str(e)}")


    def RealtimeAngleCallback(self, event):
        if not self.angle_callback_enabled:
            return
            
        try:
            realtime_angles = self.hand.read_realtime_angles()

            if realtime_angles and len(realtime_angles) == 17:
                msg = RealtimeAngle()
                msg.angles = realtime_angles
                self.realtime_angle_publisher.publish(msg)
            else:
                rospy.logwarn("Failed to read valid realtime angles")
        except Exception as e:
            rospy.logerr(f"Error in realtime angle query: {str(e)}")


    def __del__(self):
        """Automatically called when nodes are destroyed"""
        self.hand.close()
        # 修正：用 print 替换 rospy.loginfo
        print("The serial port has been closed through destructor")



def main():    
    hand_control_node = HandControlNode()
    rospy.spin()

if __name__ == '__main__':
    main()