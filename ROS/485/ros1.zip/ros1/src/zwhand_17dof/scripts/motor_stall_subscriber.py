#!/usr/bin/env python
import rospy
from zwhand_17dof.msg import *  # 替换为实际的消息包
from zwhand_17dof.srv import EnablePublishers  # 替换为实际的服务包

class StallSubscriber:
    def __init__(self):
        rospy.init_node('stall_subscriber', anonymous=True)
        
        # 订阅电机堵转信息话题
        self.subscriber = rospy.Subscriber(
            'zwhand_17dof/realtime_motor_stall',
            RealtimeMotorStall,
            self.callback
        )
        
        rospy.loginfo("Stall subscriber initialized. Waiting for stall data...")
        
        # 启用堵转信息发布者
        self.enable_publisher()
        
    def enable_publisher(self):
        """请求启用堵转信息发布者"""
        rospy.loginfo("Waiting for enable_publishers service...")
        rospy.wait_for_service('zwhand_17dof/enable_publishers')
        try:
            enable_service = rospy.ServiceProxy('zwhand_17dof/enable_publishers', EnablePublishers)
            response = enable_service(enable_angle=False, enable_stall=True)
            if response.success:
                rospy.loginfo("Successfully enabled motor stall publisher")
            else:
                rospy.logwarn("Failed to enable motor stall publisher")
        except rospy.ServiceException as e:
            rospy.logerr(f"Service call failed: {e}")
    
    def callback(self, data):
        """处理接收到的堵转数据"""
        rospy.loginfo(f"Received motor stall status: {data.motor_stall}")
        # 在这里添加处理堵转数据的代码

if __name__ == '__main__':
    try:
        subscriber = StallSubscriber()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
