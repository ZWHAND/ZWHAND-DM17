import rclpy
from rclpy.node import Node

from interface.msg import(
    RealtimeAngle
)

class AngleSubscriber(Node):
    def __init__(self):
        super().__init__('angle_subscriber')
        self.subscription = self.create_subscription(
            RealtimeAngle,
            'zwhand_17dof/realtime_angle',
            self.listener_callback,
            10 
        )
        self.subscription

    def listener_callback(self, msg):
        formatted_angles = [f"{angle:3d}" for angle in msg.angles]
        angles_str = ", ".join(formatted_angles)
        self.get_logger().info(f"Received angles data: [{angles_str}]")



def main(args=None):
    rclpy.init(args=args)
    angle_subscriber = AngleSubscriber()
    rclpy.spin(angle_subscriber)
    angle_subscriber.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
