import rclpy
from rclpy.node import Node
from .modbus_control_api import hand_serial
    
from interface.srv import(
    CalibrationAllHand,CalibrationSteppingMotors,CalibrationSingleMotor,
    ControlAllHand,ControlSingleMotor,
    ControlAllhandIncrement,ControlSingleMotorIncrement,

    SetID,
    SetBaudrate,

    SetSpeedAllHand,SetSpeedSingleMotor,
    SetCurrentAllHand,SetCurrentSingleMotor,


    RestoreFactorySettings,
    ClearError,
    StopEmergency,
    SaveConfiguration,

    GetInitializationSignal,
    
    GetBootloaderVersion,GetHardwareVersion,GetSoftwareVersion,
)
from interface.msg import(
    RealtimeAngle,
    RealtimeMotorStall
)


class HandControlNode(Node):
    def __init__(self):
        super().__init__('hand_control_node')
        self.hand = hand_serial(self)
    

        self.angle_has_subscribers = False
        self.stall_has_subscribers = False


        self.calibration_all_hand_service = self.create_service(
            CalibrationAllHand,
            'zwhand_17dof/calibration_all_hand',
            self.hand.calibrationAllHandCallback
        )
        self.calibration_stepping_motors = self.create_service(
            CalibrationSteppingMotors,
            'zwhand_17dof/calibration_stepping_motors',
            self.hand.calibrationSteppingMotorsCallback
        )
        self.calibration_single_motor = self.create_service(
            CalibrationSingleMotor,
            'zwhand_17dof/calibration_single_motor',
            self.hand.calibrationSingleMotorCallback
        )


        self.control_all_hand_service = self.create_service(
            ControlAllHand,
            'zwhand_17dof/control_all_hand',
            self.hand.controlAllHandCallback
        )
        self.control_single_motor_service = self.create_service(
            ControlSingleMotor,
            'zwhand_17dof/control_single_motor',
            self.hand.controlSingleMotorCallback
        )


        self.control_all_hand_increment_service = self.create_service(
            ControlAllhandIncrement,
            'zwhand_17dof/control_all_hand_increment',
            self.hand.ControlAllhandIncrementCallback
        )
        self.control_single_motor_increment_service = self.create_service(
            ControlSingleMotorIncrement,
            'zwhand_17dof/control_single_motor_increment',
            self.hand.ControlSingleMotorIncrementCallback
        )





        self.set_ID_service = self.create_service(
            SetID,
            'zwhand_17dof/set_id',
            self.hand.SetIdCallback
        )


        self.set_baudrate_service = self.create_service(
            SetBaudrate,
            'zwhand_17dof/set_baudrate',
            self.hand.SetBaudrateCallback
        )

        self.set_speed_all_hand_service = self.create_service(
            SetSpeedAllHand,
            'zwhand_17dof/set_speed_all_hand',
            self.hand.SetSpeedAllHandCallback
        )
        self.set_speed_single_motor_service = self.create_service(
            SetSpeedSingleMotor,
            'zwhand_17dof/set_speed_single_motor',
            self.hand.SetSpeedSingleMotorCallback
        )


        self.set_current_single_motor_service = self.create_service(
            SetCurrentSingleMotor,
            'zwhand_17dof/set_current_single_motor',
            self.hand.SetCurrentSingleMotorCallback
        )        
        self.set_current_all_hand_service = self.create_service(
            SetCurrentAllHand,
            'zwhand_17dof/set_current_all_hand',
            self.hand.SetCurrentAllHandCallback
        )   


        self.clear_error_service = self.create_service(
            ClearError,
            'zwhand_17dof/clear_error',
            self.hand.ClearErrorCallback
        )
        self.restor_factory_settings_service = self.create_service(
            RestoreFactorySettings,
            'zwhand_17dof/restor_factory_settings',
            self.hand.RestoreFactorySettingsCallback
        )


        self.stop_emergency_service = self.create_service(
            StopEmergency,
            'zwhand_17dof/stop',
            self.hand.StopEmergencyCallback
        )
        self.save_configuration_service = self.create_service(
            SaveConfiguration,
            'zwhand_17dof/save_configuration',
            self.hand.SaveConfigurationCallback
        )

        self.get_initialization_success_signal_service = self.create_service(
            GetInitializationSignal,
            'zwhand_17dof/get_initialization_success_signal',
            self.hand.GetInitializationSignalCallback
        )

        self.get_bootLoader_version_service = self.create_service(
            GetBootloaderVersion,
            'zwhand_17dof/get_bootloader_version',
            self.hand.GetBootloaderVersionCallback
        )
        self.get_hardware_version_service = self.create_service(
            GetHardwareVersion,
            'zwhand_17dof/get_hardware_version',
            self.hand.GetHardwareVersionCallback
        )
        self.get_software_version_service = self.create_service(
            GetSoftwareVersion,
            'zwhand_17dof/get_software_version',
            self.hand.GetSoftwareVersionCallback
        )
        # self. = self.create_service(
        #     ,
        #     'zwhand_17dof/',
        #     self.hand.
        # )
        # self. = self.create_service(
        #     ,
        #     'zwhand_17dof/',
        #     self.hand.
        # )
        # self. = self.create_service(
        #     ,
        #     'zwhand_17dof/',
        #     self.hand.
        # )
        # self. = self.create_service(
        #     ,
        #     'zwhand_17dof/',
        #     self.hand.
        # )
        # self. = self.create_service(
        #     ,
        #     'zwhand_17dof/',
        #     self.hand.
        # )
        # self. = self.create_service(
        #     ,
        #     'zwhand_17dof/',
        #     self.hand.
        # )
  



        # -------------------- topic communication --------------------
        self.realtime_angle_publisher  = self.create_publisher(
            RealtimeAngle,
            'zwhand_17dof/realtime_angle',
            10
        )

        


        self.realtime_motor_stall_publisher  = self.create_publisher(
            RealtimeMotorStall,
            'zwhand_17dof/realtime_motor_stall',
            10
        )

       

       # 创建定时器但不启动
        self.realtime_angle_publisher_timer = self.create_timer(
            0.1,  # 周期（秒）
            self.RealtimeAngleCallback  # 回调函数
        )
        self.realtime_angle_publisher_timer.cancel()  # 初始状态为取消
        
        self.realtime_motor_stall_publisher_timer = self.create_timer(
            0.35,  # 周期（秒）
            self.RealtimeMotorStallCallback  # 回调函数
        )
        self.realtime_motor_stall_publisher_timer.cancel()  # 初始状态为取消
        
        # 添加订阅者检查定时器
        self.subscriber_check_timer = self.create_timer(
            0.5,  # 每0.5秒检查一次订阅者状态
            self.check_subscribers
        )
        
        self.get_logger().info("Hand control node initialized successfully")

    def check_subscribers(self):
        """定期检查订阅者数量并控制发布器状态"""
        # 检查角度话题订阅者
        angle_sub_count = self.realtime_angle_publisher.get_subscription_count()
        if angle_sub_count > 0 and not self.angle_has_subscribers:
            self.angle_has_subscribers = True
            self.realtime_angle_publisher_timer.reset()  # 启动定时器
            self.get_logger().info(f"开始发布角度信息，当前订阅者数量: {angle_sub_count}")
        elif angle_sub_count == 0 and self.angle_has_subscribers:
            self.angle_has_subscribers = False
            self.realtime_angle_publisher_timer.cancel()  # 停止定时器
            self.get_logger().info("所有角度订阅者已退出，停止发布角度信息")
            
        # 检查电机堵转话题订阅者
        stall_sub_count = self.realtime_motor_stall_publisher.get_subscription_count()
        if stall_sub_count > 0 and not self.stall_has_subscribers:
            self.stall_has_subscribers = True
            self.realtime_motor_stall_publisher_timer.reset()  # 启动定时器
            self.get_logger().info(f"开始发布电机堵转信息，当前订阅者数量: {stall_sub_count}")
        elif stall_sub_count == 0 and self.stall_has_subscribers:
            self.stall_has_subscribers = False
            self.realtime_motor_stall_publisher_timer.cancel()  # 停止定时器
            self.get_logger().info("所有电机堵转信息订阅者已退出，停止发布")

    def RealtimeAngleCallback(self):
        """发布实时角度信息"""
        try:
            realtime_angles = self.hand.read_realtime_angles()

            if realtime_angles and len(realtime_angles) == 17:
                # 构造消息并发布
                msg = RealtimeAngle()
                msg.angles = realtime_angles  # 假设angles是17个整数的列表
                self.realtime_angle_publisher.publish(msg)
            else:
                self.get_logger().warn("Failed to read valid realtime angles")
        except Exception as e:
            self.get_logger().error(f"Error in realtime angle query: {str(e)}")

    def RealtimeMotorStallCallback(self):
        """发布电机堵转信息"""
        try:
            realtime_motor_stall = self.hand.read_realtime_motor_stall()

            if realtime_motor_stall and len(realtime_motor_stall) == 17:
                # 构造消息并发布
                msg = RealtimeMotorStall()
                msg.motor_stall = realtime_motor_stall
                self.realtime_motor_stall_publisher.publish(msg)
            else:
                self.get_logger().warn("Failed to read valid realtime motor stall")
        except Exception as e:
            self.get_logger().error(f"Error in realtime motor stall query: {str(e)}")



    def __del__(self):
        """Automatically called when nodes are destroyed"""
        self.hand.close()
        self.get_logger().info("The serial port has been closed through destructor")
def main(args=None):
    rclpy.init(args=args)
    hand_control_node = HandControlNode()
    rclpy.spin(hand_control_node)
    hand_control_node.destroy_node()
    rclpy.shutdown()
