import rclpy
from rclpy.node import Node

from interface.msg import(
    RealtimeMotorStall
)

class MotorStallSubscriber(Node):
    def __init__(self):
        super().__init__('motor_stall_subscriber')
        self.subscription = self.create_subscription(
            RealtimeMotorStall,
            'zwhand_17dof/realtime_motor_stall',
            self.listener_callback,
            10 
        )
        self.subscription

    def listener_callback(self, msg):
        formatted_motor_stall = [f"{motor_stall:5d}" for motor_stall in msg.motor_stall]
        motor_stall_str = ", ".join(formatted_motor_stall)
        self.get_logger().info(f"Received motor stall data: [{motor_stall_str}]")

def main(args=None):
    rclpy.init(args=args)
    motor_stall_subscriber = MotorStallSubscriber()
    rclpy.spin(motor_stall_subscriber)
    motor_stall_subscriber.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
