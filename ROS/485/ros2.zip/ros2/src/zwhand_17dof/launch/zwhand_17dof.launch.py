# zwhand_17dof.launch.py
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import LaunchConfiguration
from launch.actions import DeclareLaunchArgument  # 关键：显式声明参数的动作

def generate_launch_description():
    # 1. 显式声明所有需要的参数（Jazzy必须）
    declare_port_arg = DeclareLaunchArgument(
        name='port',  # 参数名
        default_value='/dev/ttyUSB0',  # 默认值
        description='Serial port device path (e.g., /dev/ttyUSB0)'  # 描述
    )
    
    declare_baud_arg = DeclareLaunchArgument(
        name='baud',
        default_value='115200',
        description='Serial port baud rate'
    )
    
    declare_hand_id_arg = DeclareLaunchArgument(
        name='hand_id',
        default_value='1',
        description='ID of the robotic hand'
    )
    
    declare_test_flags_arg = DeclareLaunchArgument(
        name='test_flags',
        default_value='0',
        description='Test mode flags (0=disable, 1=enable)'
    )

    # 2. 定义节点启动配置
    hand_node = Node(
        package='zwhand_17dof',
        executable='hand_control',  # 对应setup.py中定义的可执行文件
        name='hand_control_node',   # 节点名称
        output='screen',
        parameters=[
            {
                'port': LaunchConfiguration('port'),  # 引用声明的参数
                'baud': LaunchConfiguration('baud'),
                'hand_id': LaunchConfiguration('hand_id'),
                'test_flags': LaunchConfiguration('test_flags')
            }
        ]
    )

    # 3. 组装LaunchDescription（必须包含参数声明和节点）
    return LaunchDescription([
        declare_port_arg,
        declare_baud_arg,
        declare_hand_id_arg,
        declare_test_flags_arg,
        hand_node
    ])
