zwhand_17dof功能包支持兆威17自由度灵巧手在ROS2平台上的使用,该功能包在Ubuntu 24.04系统的ROS 2 Jazzy环境下进行测试.
1.配置ROS2 Jazzy环境,安装方式如下:
	(1)设置编码格式
	sudo apt update && sudo apt install locales

	sudo locale-gen en_US en_US.UTF-8

	sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8 

	export LANG=en_US.UTF-8
	(2)Ubuntu换源
	sudo apt update

	sudo apt install vim -y
	# 备份
	cp /etc/apt/sources.list.d/ubuntu.sources /etc/apt/sources.list.d/ubuntu.sources.bak

	vim /etc/apt/sources.list.d/ubuntu.sources
	用以下内容覆盖文件
	# 阿里云
	Types: deb
	URIs: http://mirrors.aliyun.com/ubuntu/
	Suites: noble noble-updates noble-security
	Components: main restricted universe multiverse
	Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
	(3)安装ros2
	sudo apt update

	sudo apt-get install -y

	sudo apt install software-properties-common -y

	sudo add-apt-repository universe # 按后面Enter

	sudo apt update && sudo apt install curl gnupg2 -y

	sudo curl -sSL https://gitee.com/tyx6/rosdistro/raw/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg

	echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

	sudo apt install curl gnupg2 -y

	# 这一步先打开科学上网，不然会报错
	curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key -o /usr/share/keyrings/ros-archive-keyring.gpg

	# 这一步先关闭科学上网，不然会报错
	sudo apt update && sudo apt upgrade

	sudo apt install ros-jazzy-desktop -y
	(4)添加终端启动sh
	echo "source /opt/ros/jazzy/setup.bash" > ~/.bashrc
	(5)安装必要的第三方库
	sudo apt install python3-colcon-common-extensions -y
	(6)测试示例
	启动第一个终端
	ros2 run turtlesim turtlesim_node
	启动第二个终端
	ros2 run turtlesim turtle_teleop_key
2.安装本地环境
	(1)创建工作空间
	mkdir -p ~/{workspace_name}/src
	cd ~/{workspace_name}
	colcon build
	将src文件夹中的内容复制到创建工作空间中的src文件夹中
	
	
	（2）对端口进行权限设置，可以选择临时方案或者是永久方案
        (1) 临时方案（每次使用都需要设置）。终端指令：sudo chmod a+rw /dev/ttyUSB*（* 是串口号）
        (2) 永久方案。
			sudo vim -p /etc/udev/rules.d/70-ttyUSB.rules
			在打开的文件中输入：
			KERNEL=="ttyUSB*", OWNER="root", GROUP="root", MODE="0666"
			保存关闭之后，重启电脑即可。（注意KERNEL=="ttyUSB*",这里的*不是串口号就是*）
	
	
	

	
3.控制灵巧手
	(1)连接串口：
		默认参数连接
			ros2 launch zwhand_17dof zwhand_17dof.launch.py 
		设置参数连接
			ros2 launch zwhand_17dof zwhand_17dof.launch.py "{port:="/dev/ttyUSB0", baud:="115200"}"
	(2)在另一个终端启动服务：
	配置环境变量
		source install/setup.bash
	接下来可以启动以下灵巧手服务：
	动作控制：
		全手校准
			ros2 service call /zwhand_17dof/calibration_all_hand interface/srv/CalibrationAllHand
		全步进电机校准
			ros2 service call /zwhand_17dof/calibration_stepping_motors interface/srv/CalibrationSteppingMotors
		单电机校准：
			ros2 service call /zwhand_17dof/calibration_single_motor interface/srv/CalibrationSingleMotor "{motor_id: 0}"
				输入电机id号，范围0-16,整数
		单电机绝对值控制：
			ros2 service call /zwhand_17dof/control_single_motor interface/srv/ControlSingleMotor "{motor_id: 0, angles: 0}"
				输入电机id号，范围0-16；	输入角度，范围0-1000,整数
		单电机增量控制：
			ros2 service call /zwhand_17dof/control_single_motor_increment interface/srv/ControlSingleMotorIncrement "{motor_id: 0, angles: 0}"	
				输入电机id号，范围0-16；	输入角度增量，范围0-1000,整数
		全手绝对值控制：
			ros2 service call /zwhand_17dof/control_all_hand interface/srv/ControlAllHand "{angles: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}"
				输入17个角度，范围0-1000,整数
		全手增量控制：
			ros2 service call /zwhand_17dof/control_all_hand_increment interface/srv/ControlAllhandIncrement "{angles: [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}"
				输入17个角度，范围0-1000,整数
		设置急停：
、			 ros2 service call /zwhand_17dof/stop interface/srv/StopEmergency
	设置参数：
		设置灵巧手ID
			ros2 service call /zwhand_17dof/set_id interface/srv/SetID "{hand_id: 1}"
		设置波特率
			允许输入的波特率为{9600, 115200, 1152000}
			ros2 service call /zwhand_17dof/set_baudrate interface/srv/SetBaudrate "{baudrate: 115200}"
		设置全手速度
			ros2 service call /zwhand_17dof/set_speed_all_hand interface/srv/SetSpeedAllHand "{velocity: [80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80]}"
				输入电机速度，范围0-100,整数
		设置单电机速度
			ros2 service call /zwhand_17dof/set_speed_single_motor interface/srv/SetSpeedSingleMotor "{motor_id: 1,velocity: 100}"
				输入电机id号，范围0-16；	输入电机速度，范围0-100,整数
		设置全手电流
			ros2 service call /zwhand_17dof/set_current_all_hand interface/srv/SetCurrentAllHand "{current: [80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80]}"
				输入电机电流，范围0-100,整数
		设置单电机电流
			ros2 service call /zwhand_17dof/set_current_single_motor interface/srv/SetCurrentSingleMotor "{motor_id: 1,current: 100}"
				输入电机id号，范围0-16；	输入电机电流，范围0-100,整数
		设置掉电保存参数
			ros2 service call /zwhand_17dof/save_configuration interface/srv/SaveConfiguration
		清楚错误：
			ros2 service call /zwhand_17dof/clear_error interface/srv/ClearError
		恢复出厂设置：
			ros2 service call /zwhand_17dof/restor_factory_settings interface/srv/RestoreFactorySettings 
		


	读取参数：
		读取初始化成功信号：
			ros2 service call /zwhand_17dof/get_bootloader_version interface/srv/GetBootloaderVersion
		读取BootLoader版本号：
			ros2 service call /zwhand_17dof/get_hardware_version interface/srv/GetHardwareVersion
		读取硬件版本号：
			ros2 service call /zwhand_17dof/get_hardware_version interface/srv/GetHardwareVersion
		读取软件版本号：
			ros2 service call /zwhand_17dof/get_software_version interface/srv/GetSoftwareVersion
		
		
	(3)在新的终端可以读取电机实时状态：
		全手实时角度：
			启动新终端
				source install/setup.bash
				ros2 run zwhand_17dof angle_subscriber
		全手堵转情况：
			启动新终端
				source install/setup.bash
				ros2 run zwhand_17dof motor_stall_subscriber